--------------------------------------------------------------------------------
-- Author:      Alberto Dell'Era
-- Copyright:   (c) 2008, 2009 Alberto Dell'Era http://www.adellera.it
--------------------------------------------------------------------------------

type optim_env_sys_params_t is table of varchar2(40) index by varchar2(40);
m_optim_env_sys_params optim_env_sys_params_t;