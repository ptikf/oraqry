xplan utility - copyright (C) 2008-2017 Alberto Dell'Era, www.adellera.it

Put all files in a directory of your choice.

Change local directory to that directory (or add it to your SQLPATH environment variable).

Log in sqlplus, than run the script
@xplan <sql like> <options, comma-separated>

See xplan.sql comment header for more informations.

